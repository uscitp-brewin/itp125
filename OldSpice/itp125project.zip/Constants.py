USAGE_STATEMENT = """usage: Voicemail.py -g < 0 (male)/ 1 (female)>
-n <phoneNumber> -r <reasons (nums, no spaces)> -e <ending (nums, no spaces)>
-o <output name>"""

MALE_OPTION = 0
FEMALE_OPTION = 1

PHONE_SEG1_LEN = 3
PHONE_SEG2_LEN = 3
PHONE_SEG3_LEN = 4
