To run:
python Vocemail.py [optional arguments]
